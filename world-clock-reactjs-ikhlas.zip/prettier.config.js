module.exports = {
  arrowParens: 'avoid',
  endOfLine: 'auto',
  jsxBracketSameLine: false,
  jsxSingleQuote: false,
  printWidth: 120,
  singleQuote: true,
  tabWidth: 2,
  trailingComma: 'es5',
  useTabs: false,
};
