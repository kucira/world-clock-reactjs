export const BASE_URL = 'https://worldtimeapi.org/api';
export const TIMEZONE_ENDPOINT  = `${BASE_URL}/timezone`;
export const TIMEZONE_IP_ENDPOINT  = `${BASE_URL}/ip`;
